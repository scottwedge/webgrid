
class FakeView(object):
    pass

class InNewsComp3(object):
    pass

class News1HasPriority(object):
    pass

class InNlSupporting(object):
    pass

class InNewsComp2(object):
    pass