
obj1 = 'mobj1'
obj2 = 'mobj2'