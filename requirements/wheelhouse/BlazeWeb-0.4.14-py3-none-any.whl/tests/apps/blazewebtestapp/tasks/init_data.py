
def action_010():
    return 'lots of data'

