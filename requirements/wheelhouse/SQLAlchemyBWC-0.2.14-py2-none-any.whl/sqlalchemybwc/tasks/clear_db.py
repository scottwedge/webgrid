from compstack.sqlalchemy.lib.helpers import clear_db

def action_50_drop_db_objects():
    clear_db()
