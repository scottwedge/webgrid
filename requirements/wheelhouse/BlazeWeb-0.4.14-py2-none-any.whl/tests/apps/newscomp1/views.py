
class FakeView(object):
    pass

class InNewsComp1(object):
    pass

class News1HasPriority(object):
    pass

class InAppHasPriority(object):
    pass