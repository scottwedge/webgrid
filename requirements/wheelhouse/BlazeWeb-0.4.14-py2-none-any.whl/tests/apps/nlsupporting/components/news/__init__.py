
def somefunc():
    pass
