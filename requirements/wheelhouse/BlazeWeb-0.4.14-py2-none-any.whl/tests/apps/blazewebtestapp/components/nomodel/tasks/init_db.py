
loc = 'blazewebtestapp.modules.nomodel.tasks.init_db'
