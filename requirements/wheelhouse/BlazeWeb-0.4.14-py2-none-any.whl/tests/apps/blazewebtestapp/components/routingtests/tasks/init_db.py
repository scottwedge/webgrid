
loc = 'blazewebtestapp.components.routingtests.tasks.init_db'

def action_001():
    return loc
