from blazeweb.views import View
from compstack.nothere import something

class Index(View):
    def default(self):
        pass
