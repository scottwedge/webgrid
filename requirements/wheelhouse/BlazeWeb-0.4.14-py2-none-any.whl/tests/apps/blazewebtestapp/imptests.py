
obj1 = 'obj1'
obj2 = 'obj2'