
def action_010():
    print 'doit'

