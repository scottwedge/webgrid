
class FakeView(object):
    pass