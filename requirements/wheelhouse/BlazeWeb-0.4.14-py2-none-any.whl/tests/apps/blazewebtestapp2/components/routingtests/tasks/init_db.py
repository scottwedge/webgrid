
loc = 'blazewebtestapp2.components.routingtests.tasks.init_db'

def action_001():
    return loc

def action_003():
    return loc
