
loc = 'blazewebtestapp2.tasks.init_db'
loctoo = 'blazewebtestapp2.tasks.init_db'

def action_001():
    return loctoo

def action_005():
    return loctoo
